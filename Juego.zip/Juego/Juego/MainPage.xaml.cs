﻿namespace Juego
{
    public partial class MainPage : ContentPage
    {
        int count = 0;

        public MainPage()
        {
            InitializeComponent();

            SetUpGame();
        }
        private void SetUpGame()
        {
            List<string> animalEmoji = new List<string>()
            {

                "🐶", "🐶",
                "🐵","🐵",
                 "🐙","🐙",
                 "🐘","🐘",
                 "🦓","🦓",
                 "🦒","🦒",
                "🦆","🦆",
                "🐬","🐬",
            };
            Random ramdom = new Random();
            foreach(Button view in Grid1.Children)
            {
                int index = ramdom.Next(animalEmoji.Count);
                string nextEmoji  = animalEmoji[index];
                view.Text=nextEmoji;
                animalEmoji.RemoveAt(index);
            }
            
        }
        Button ultimoButtonCliked;
        bool encontradoMatch = false;

        private void Button_Clicked(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (encontradoMatch == false)
            {
                button.IsVisible = false;
                ultimoButtonCliked = button;
                encontradoMatch = true;
            }
            else if (button.Text == ultimoButtonCliked.Text)
            {
                button.IsVisible = false;
                encontradoMatch = false;
            }
            else
            {
                ultimoButtonCliked.IsVisible = true;
                encontradoMatch = false;
            }
        }

       // private void Button_Clicked(System.Object sender, System.EventArgs e)
        //{

        //}

        private void Button_Clicked_1(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_2(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_3(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_4(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_5(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_6(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_7(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_8(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_9(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_10(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_11(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_12(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_13(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_14(System.Object sender, System.EventArgs e)
        {

        }

        private void Button_Clicked_15(System.Object sender, System.EventArgs e)
        {

        }
    }

}
