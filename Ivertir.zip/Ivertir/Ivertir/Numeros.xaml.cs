namespace Ivertir;

public partial class Numeros : ContentPage
{
	public Numeros()
	{
		InitializeComponent();
	}

    private void Button_Clicked(object sender, EventArgs e)
    {
		try
		{
			int num1 = int.Parse(Number1.Text);
			int num2 = int.Parse(Number2.Text);
			int numb3 = int.Parse(Number3.Text);
			int num4 = int.Parse(Number4.Text);

			int[] numbers = { num1, num2, numb3, num4 };

			Array.Reverse(numbers);
			
			Resultado.Text= $"Numeros invertidos:{numbers[0]},{numbers[1]},{numbers[2]},{numbers[3]}";


		}
		catch(Exception ex)
		{
			Resultado.Text="Ingrese los cuantro numeros";
		}
    }

  
}