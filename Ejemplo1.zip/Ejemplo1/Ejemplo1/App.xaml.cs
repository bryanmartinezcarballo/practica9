﻿namespace Ejemplo1
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new Paginauno();
        }
    }
}
