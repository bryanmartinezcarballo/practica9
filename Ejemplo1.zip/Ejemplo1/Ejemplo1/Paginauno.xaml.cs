namespace Ejemplo1;

public partial class Paginauno : ContentPage
{
	public Paginauno()
	{
		InitializeComponent();
	}
}