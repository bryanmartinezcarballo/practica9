namespace Triangulo;

public partial class NewPage1 : ContentPage
{
	public NewPage1()
	{
		InitializeComponent();
	}

    private void Button_Clicked(object sender, EventArgs e)
    {
        double altura = Convert.ToDouble(Altura.Text);
        double baseRectangulo = Convert.ToDouble(Base.Text);

       
        double perimetro = 2 * (altura + baseRectangulo);
        double area = altura * baseRectangulo;

      
        Perimetro.Text = $"El per�metro del rect�ngulo es: {perimetro}";
        Area.Text = $"El �rea del rect�ngulo es: {area}";
    }
}