namespace Cuadrado;

public partial class NewPage1 : ContentPage
{
	public NewPage1()
	{
		InitializeComponent();
	}

   

    private void Button_Clicked_1(object sender, EventArgs e)
    {

        int numero = Convert.ToInt32(Num.Text);

        
        int cuadrado = numero * numero;
        int cubo = numero * numero * numero;

       
        Cuadrado.Text = $"El cuadrado de {numero} es: {cuadrado}";
        Cubo.Text = $"El cubo de {numero} es: {cubo}";

    }
}